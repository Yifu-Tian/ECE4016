# BOLA: Near-Optimal Bitrate Adaptation for Online Videos
# BOLA-BASIC Implementation by Yifu TIAN

import numpy as np

def student_entrypoint(Measured_Bandwidth, Previous_Throughput, Buffer_Occupancy, Available_Bitrates, Video_Time, Chunk, Rebuffering_Time, Preferred_Bitrate):
    
    # Convert the available bitrates dictionary to a sorted list of tuples based on bitrate value.
    bitrates_array = list(Available_Bitrates.items())
    bitrates_array.sort(key=lambda tup: tup[1] , reverse=True)
    
    # Call BOLA function and return the optimal bitrate
    return BOLA(bitrates_array, Buffer_Occupancy)

def BOLA(bitrates_array, buffer_size):
    '''
    I only implemented BOLA-BASIC here
    
    V: A parameter that affects the trade-off between high bitrate and rebuffering risk
    p: A parameter related to buffer content
    gamma: A parameter that translates the utility function to avoid rebuffering
    CHUNK_TIME: The duration of each video chunk in seconds.
    S_m: A dictionary that maps each bitrate to its corresponding chunk size
    Q: A parameter that indicates the number of buffered chunks.(This spends me a lot of time to figure out)
    
    list_of_utility: A list to store the result of each goal_formula
    '''
    V = 1.015
    p = 5
    gamma = 1
    CHUNK_TIME = 2
    S_m = {br: size for br, size in bitrates_array}
    list_of_utility = []
    
    for br, sz in bitrates_array:
        
        # Calculate utility for each bitrate, we will use this in goal_formula
        utility = np.log(sz / S_m[br])
        
        # Q indicated the number of buffered chunks
        Q = buffer_size["time"] / CHUNK_TIME
        
        # goal_formula is the formula we want to maximize
        goal_formula = (V * utility + V * p * gamma - Q) / S_m[br]
        
        list_of_utility.append(goal_formula)
    
    # Select the index of the bitrate with the maxium utility
    optimal_bitrate_index = np.argmax(list_of_utility)
    optimal_bitrate = bitrates_array[optimal_bitrate_index][0]
    return optimal_bitrate